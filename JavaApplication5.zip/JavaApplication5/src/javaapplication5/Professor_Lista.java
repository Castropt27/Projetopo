package javaapplication5;

import java.util.ArrayList;

public class Professor_Lista extends Professor {

    private ArrayList<Professor> listaProf;

    public Professor_Lista(String novonome, String novoServiço, int novonummec, int novodatainicio, String novoucs) {
        super(novonome, novoServiço, novonummec, novodatainicio, novoucs);
        listaProf = new ArrayList<>();
    }

    public void inserirlista(Professor professor) {
        listaProf.add(professor);
    }

    public void loginProfessor(int nummecProf) {
        boolean codigoencontrado = false;
        for (Professor professor : listaProf) {
            if (professor.getnummecP() == (nummecProf)) {
                System.out.println("Login bem-sucedido");
                codigoencontrado = true;
                break;
            }
        }

        if (!codigoencontrado) {
            System.out.println("Código de utilizador inválido");
        }

    }

    public ArrayList<Professor> listaProfessoresporCurso(String designaCurso) {
        ArrayList<Professor> ProfessoresporCurso = new ArrayList<>();

        for (Professor professor : listaProf) {
            if (professor.getdesignaCurso().equals(designaCurso)) {
                ProfessoresporCurso.add(professor);
                break;
            }
        }

        return ProfessoresporCurso;
    }

}
