package javaapplication5;

public class utilizador {

}
