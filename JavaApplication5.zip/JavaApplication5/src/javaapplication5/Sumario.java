package javaapplication5;

public class Sumario extends Professor {

    private int datainicioS;
    private int datafimS;
    private String presenças;
    private String titulo;
    private String Tipo;

    public Sumario(String nomeucs, String regenteucs, int numregente, String tipoucs, String novonome, String novonomeucs, String novoServiço, int novonummec, int novodatainicio, int novodatainicioS, int novodatafimS, String novopresenças, String novotitulo, String novoTipo) {
        super(nomeucs, regenteucs, numregente, tipoucs, novonome, novoServiço, novonummec, novodatainicio, novonomeucs);
        datainicioS = novodatainicioS;
        datafimS = novodatafimS;
        presenças = novopresenças;
        titulo = novotitulo;
        Tipo = novoTipo;

    }

    public int getdatainicioS() {
        return datainicioS;
    }

    public void setdatainicoS(int novodatainicioS) {
        datainicioS = novodatainicioS;
    }

    public int getdatafimS() {
        return datafimS;
    }

    public void setdatafimS(int novodatafimS) {
        datafimS = novodatafimS;
    }

    public String getpresenças() {
        return presenças;
    }

    public void setpresenças(String novopresenças) {
        presenças = novopresenças;
    }

    public String gettitulo() {
        return titulo;
    }

    public void settitulo(String novotitulo) {
        titulo = novotitulo;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String novoTipo) {
        Tipo = novoTipo;
    }
}
