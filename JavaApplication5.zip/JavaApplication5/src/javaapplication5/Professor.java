package javaapplication5;

public class Professor extends Departamento {

    private String nome;
    private int nummecP;
    private int datainicio;
    private String ucs;
    private String Serviço;

    public Professor(String novonome, String novoServiço, int novonummecP, int novodatainicio, String novoucs) {
        nome = novonome;
        nummecP = novonummecP;
        datainicio = novodatainicio;
        ucs = novoucs;
        Serviço = novoServiço;
    }

    public int getdatainicioo() {
        return datainicio;
    }

    public String getServiço() {
        return Serviço;
    }

    public String getNome() {
        return nome;
    }

    public int getnummecP() {
        return nummecP;
    }

    public void setnummecP(int novonummecP) {
        nummecP = novonummecP;
    }

    public void setnome(String novonome) {
        nome = novonome;
    }

    public void setdatainicio(int novodatainicio) {
        datainicio = novodatainicio;
    }

    public String getucs() {
        return ucs;
    }

    public void setucs(String novoucs) {
        ucs = novoucs;
    }

    public void setServiço(String novoServiço) {
        Serviço = novoServiço;
    }

    Object getdesignaCurso() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
