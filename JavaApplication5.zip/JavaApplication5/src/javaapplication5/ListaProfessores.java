package javaapplication5;
public class ListaProfessores {
    
}
