package javaapplication5;

public class UCS {

    private String nomeucs;
    private String regenteucs;
    private int numregente;
    private String tipoucs;

    public UCS(String novonomeucs, String novoregenteucs, int novonumregente, String novotipoucs) {
        novonomeucs = nomeucs;
        novoregenteucs = regenteucs;
        novonumregente = numregente;
        novotipoucs = tipoucs;
    }

    public int getnumregente() {
        return numregente;
    }

    public String getnomeucs() {
        return nomeucs;
    }

    public String getregenteucs() {
        return regenteucs;
    }

    public void setnumregente(int novonumregente) {
        numregente = novonumregente;
    }

    public void setnomeucs(String novonomeucs) {
        nomeucs = novonomeucs;
    }

    public void setregenteucs(String novoregenteucs) {
        regenteucs = novoregenteucs;
    }

    public String gettipoucs() {
        return tipoucs;
    }

    public void gettipoucs(String novotipoucs) {
        tipoucs = novotipoucs;
    }
}
