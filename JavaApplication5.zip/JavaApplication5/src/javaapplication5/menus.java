package javaapplication5;

import java.util.Scanner;

public class menus {

    public void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();

    }

    public void menu() {
        Scanner scanner = new Scanner(System.in);
        int opcao;
        do {
            System.out.println("Atores do Sistema Informático");
            System.out.println("1. Administrador");
            System.out.println("2. Professor");
            System.out.println("3. Regente de UC");
            System.out.println("4. Diretor de Curso");
            System.out.println("0. Sair");
            System.out.print("Escolha o ator (1-4) ou 0 para sair: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1 ->
                    menuAdministrador();
                case 2 ->
                    menuProfessor();
                case 3 ->
                    menuRegenteUC();
                case 4 ->
                    menuDiretorCurso();
                case 0 ->
                    System.out.println("Saindo do sistema.");
                default ->
                    System.out.println("Opção inválida. Tente novamente.");
            
          menu();
            }
        } while (opcao != 0);
    }

    public void menuAdministrador() {
        clearScreen();
        // ler dados de login 
        if (/*dados invalidos*/) {
            System.out.println("Dados invalidos!");
            menu();
        } else {
            Scanner scanner = new Scanner(System.in);
            int opcao;
            do {
                System.out.println("Logado com sucesso!");
                System.out.println("O que deseja fazer?");
                System.out.println("1. Adicionar, apagar ou alterar informação dos professores");
                System.out.println("2. Registar ou alterar informação de cursos e UCs");
                System.out.println("3. Listar cursos, UCs, alunos ou professores registados no sistema");
                System.out.println("4. Atribuir direção de curso ou regência de UC a professor");
                System.out.println("0. Sair");
                opcao = scanner.nextInt();

                switch (opcao) {
                    case 1 ->
                        //alterar info dos professores
                            
                    case 2 ->
                        //registrar e alterar info das ucs
                    case 3 ->
                            
                    case 4 ->
                        menuDiretorCurso();
                    case 0 ->
                        System.out.println("Saindo do sistema.");
                    menu();
                        default ->
                        System.out.println("Opção inválida. Tente novamente.");
                }
            } while (opcao != 0);
        }

    }

    public void menuProfessor() {
        clearScreen();
        Scanner scanner = new Scanner(System.in);
        int opcao;
        do {
            System.out.println("1. Criar sumário");
            System.out.println("2. Consultar lista de sumários por UC e por tipo de aula");
            System.out.println("3. Consultar serviço docente");
            System.out.println("0. Sair");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1 ->
                    //criar sumario
        
                case 2 ->
                    //consultar lista de sumarios
                case 3 ->
                    // consultar serviço docente
                case 0 ->
                    System.out.println("Saindo do sistema.");
                menu();
                        default ->
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 0);
    }

    public void menuRegenteUC() {
        clearScreen();
        Scanner scanner = new Scanner(System.in);
        int opcao;
        do {
            System.out.println("1. Adicionar alunos");
            System.out.println("2. Remover aluno");
            System.out.println("3. Consultar assiduidade de determiando aluno");
            System.out.println("0. Sair");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1 ->
                    //adicionar aluno
                case 2 ->
                    //remover aluno 
                case 3 ->
                    //consultar assiduidade de determinado aluno
                case 0 ->
                    System.out.println("Saindo do sistema.");
                menu();
                    default ->
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 0);
    }

    public void menuDiretorCurso() {
        clearScreen();
        Scanner scanner = new Scanner(System.in);
        int opcao;
        do {
            System.out.println("1. Alterar designação do curso");
            System.out.println("2. Listar número de professores");
            System.out.println("3. Listar número de alunos");
            System.out.println("0. Sair");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1 ->
                    //Alterar designação do curso
                case 2 ->
                    //Listar número de professores
                case 3 ->
                    //Listar número de alunos
                case 0 ->
                    System.out.println("Saindo do sistema.");
                menu();
                    default ->
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 0);
    }
}
