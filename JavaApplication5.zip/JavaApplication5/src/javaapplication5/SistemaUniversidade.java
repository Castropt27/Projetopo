package javaapplication5;

import java.util.Scanner;

public class SistemaUniversidade {

    public static void main(String[] args) {
        menus menu = new menus();
        menu.menu();

    }

}
