package javaapplication5;

import java.util.ArrayList;

public class Alunos extends Departamento {

    private String nomeA;
    private int nummec;
    private int datainicio; // ver isto 
    private String CursoA;
    private ArrayList<UCS> ucs;
    
    public Alunos(String novonome, int novonummec, int novodatainicio, String novodesi, String novoucs) {
        nomeA = novonome;
        nummec = novonummec;
        datainicio = novodatainicio;
        this.CursoA = CursoA;
        this.ucs = new ArrayList<>();
    }

    public String getCursoA(){
        return CursoA;
    }
    public void setCursoA(String novoCursoA){
        CursoA = novoCursoA;
    }
    public int getdatainicioo() {
        return datainicio;
    }

    public String getNome() {
        return nomeA;
    }

    public int getnummec() {
        return nummec;
    }

    public void setnummec(int novonummec) {
        nummec = novonummec;
    }

    public void setnome(String novonome) {
        nomeA = novonome;
    }

    public void setdatainicio(int novodatainicio) {
        datainicio = novodatainicio;
    }
}
