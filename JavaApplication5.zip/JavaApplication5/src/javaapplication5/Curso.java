package javaapplication5;
import java.util.ArrayList;

public class Curso extends UCS {

    private String desi;
    private String direcur;
    //private ArrayList<Professor> listaProfCurso;
    private ArrayList<Alunos> listaACurso;

    public Curso(String novodesi, String novoucs, String novodirecur, String nomeucs, String regenteucs, int numregente, String tipoucs) {

        super(nomeucs, regenteucs, numregente, tipoucs);
        desi = novodesi;
        direcur = novodirecur;
        this.listaACurso = new ArrayList<>();
    }
    
    public ArrayList<Alunos> getListaACurso() {
        return listaACurso;
    }
    
    public void setListaACurso(ArrayList<Alunos> listaACurso) {
        this.listaACurso = listaACurso;
    }
    
    
    public String getdesi() {
        return desi;
    }

    public String getdirecur() {
        return direcur;
    }

    public void setdesi(String novodesi) {
        desi = novodesi;
    }

    public void setdirecur(String novodirecur) {
        direcur = novodirecur;
    }
}
